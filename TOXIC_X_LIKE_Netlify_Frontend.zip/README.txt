TOXIC X LIKE - Netlify Frontend
GitHub repository root-এ index.html, style.css, app.js এবং README.txt upload করুন।
Netlify build command ফাঁকা রাখুন; publish directory দিন: .
এটি শুধু frontend preview। API চালাতে Python backend আলাদা hosting-এ deploy করে app.js-এর API_BASE-এ backend URL বসাতে হবে। API key কখনো GitHub বা frontend-এ রাখবেন না।
